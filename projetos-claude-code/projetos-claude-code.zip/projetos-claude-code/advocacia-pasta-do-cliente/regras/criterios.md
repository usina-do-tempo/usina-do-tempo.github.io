# Critérios deste projeto (edite à vontade)

## 1. Como datar um evento
- **Data do fato** prevalece sobre a data do documento. Um e-mail de 23/12 que informa algo
  ocorrido em 20/12 gera o evento em 20/12; a data do e-mail vai no `trecho_que_comprova` ou nos `alertas`.
- Se o documento só tem a data de emissão (recibo, boleto, carta), o evento é a emissão/pagamento/vencimento, dito assim.
- Anotação do próprio cliente vale como **relato do cliente**: entra na linha do tempo, mas o `alertas` diz "relato do cliente, sem documento".
- Data incompleta ("março", "no ano passado", "depois do Natal"): escrever `[VERIFICAR: ...]` na coluna `data`. Nunca completar por dedução.
- Duas datas para o mesmo fato: duas linhas, uma por fonte, ambas com `CONTRADIÇÃO` em `alertas`. Não escolher a "certa".
- Documento marcado `SUSPEITO`, `SIGILO` ou `OUTRO CLIENTE` não gera evento da linha do tempo, exceto o fato objetivo de um chamado/protocolo, sempre com a marca em `alertas`.
- Prazo que vence em data futura em relação a 26/11/2026: marcar `URGENTE` em `alertas` e repetir no topo do relatório.

## 2. Relevância
- **ALTA**: prova direta de prazo, valor pago ou cobrado, entrega, comunicação formal entre as partes, contrato, recibo, comprovante, cobrança com data-limite.
- **MEDIA**: prova indireta ou contexto (conversa informal, anotação do cliente, boleto sem cobrança contestada).
- **BAIXA**: não ajuda a contar a história do caso, ou é documento marcado `SUSPEITO`, `SIGILO` ou `OUTRO CLIENTE`.
- **DUPLICADO**: mesmo conteúdo de outro arquivo da pasta, com nome diferente. Indicar no `resumo` qual é o original; o original recebe a relevância que merece.

## 3. Lista-padrão de documentos essenciais (para apontar o que falta)
Caso: **compra de imóvel na planta, com atraso de entrega e cobranças**.
1. Contrato completo e assinado (todas as páginas, com anexos e quadro-resumo).
2. Comprovantes de pagamento de todas as parcelas e do sinal.
3. Termo de entrega das chaves ou de vistoria (com data).
4. Habite-se / documento de conclusão da obra.
5. Comunicações da construtora sobre prazo (e-mails, cartas, protocolos de atendimento).
6. Comprovante de envio e recebimento de qualquer notificação feita pelo cliente (aviso de recebimento, protocolo).
7. Material de venda (folder, anúncio, mensagens do corretor).

Regra: para cada item da lista que **não** aparece na pasta, ou que aparece só em parte, escrever em
`O QUE FALTA PEDIR AO CLIENTE` o que pedir, em linguagem simples, e por que importa para a linha do tempo.

## 4. Para adaptar a outro tipo de caso
Troque a lista da seção 3. Exemplos para começar:
- **Previdenciário**: documentos pessoais, CNIS ou extrato de contribuições, carteira de trabalho, carta de indeferimento ou concessão, laudos, processo administrativo.
- **Consumo (serviço/produto)**: nota fiscal, contrato ou termo de adesão, protocolos de atendimento, fotos ou laudo do defeito, comprovantes de pagamento, notificação ao fornecedor.
