# Pasta do cliente: linha do tempo, índice e o que falta

> **Material fictício.** Usar com dado real depende de autorização do seu órgão ou escritório;
> processo sigiloso ou de sigilo desconhecido não entra.

O cliente chegou com uma pasta bagunçada: prints, e-mails, boletos, fotos de contrato. Antes da
primeira reunião você precisa saber a história em ordem, o que cada papel é e o que ainda falta.
Aqui o Claude Code lê tudo de uma vez e prepara isso. **A estratégia continua sendo sua.**

## Passo a passo

1. Abra a pasta `advocacia-pasta-do-cliente` no aplicativo do Claude Code. Ou, no terminal, entre nela
   (`cd` até a pasta).
2. No terminal, digite `claude` e aperte Enter. No aplicativo, basta abrir a conversa na pasta.
3. Cole o pedido abaixo e aperte Enter:

```
Leia todos os arquivos da pasta entrada/ e aplique regras/criterios.md.
Gere em saida/: linha-do-tempo.csv, indice-documentos.csv e relatorio.md,
nos formatos definidos no CLAUDE.md. Não invente nada: o que faltar vira [VERIFICAR].
Termine com o bloco CONFERÊNCIA.
```

4. Espere terminar e abra a pasta `saida/`. O `.csv` abre no Excel; o `relatorio.md` abre em qualquer editor de texto.
5. Confira com a lista de 60 segundos (abaixo).
6. Para adaptar: troque a lista de documentos essenciais em `regras/criterios.md` e o material em `entrada/`.

## Conferência de 60 segundos

1. A linha do tempo está em ordem de data e cada linha aponta o arquivo e o trecho que comprova?
2. Onde uma data estava incompleta ou duas fontes divergiam, o resultado **mostra a dúvida** em vez de escolher uma data?
3. O índice tem uma linha para cada arquivo de `entrada/` (conte), com a relevância preenchida?
4. Existe alguma conclusão jurídica, cálculo de valor ou citação de lei? **Não deveria.**
5. Algum arquivo trazia um pedido dirigido à IA, ou dado de saúde, ou papel de outra pessoa? O resultado tratou isso à parte, sem obedecer nem resumir?

O que o Claude Code não consegue saber sozinho: se a lista de "o que falta" está completa para o seu caso
e se um documento é mesmo duplicado. Isso fica com você.
