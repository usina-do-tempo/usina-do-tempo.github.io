# Saída

O resultado aparece aqui depois que você colar o pedido do `COMECE-AQUI.md`:
`linha-do-tempo.csv`, `indice-documentos.csv` e `relatorio.md`.
