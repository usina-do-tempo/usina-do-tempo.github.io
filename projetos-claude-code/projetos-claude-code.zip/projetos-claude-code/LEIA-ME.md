# Projetos prontos de Claude Code · Mentoria Regente

Quatro pastas prontas para abrir no Claude Code, colar um pedido e conferir o resultado.
Tudo é **fictício**. A lição é sempre a mesma: **pasta → pedido → achados → conferência humana.**

| Pasta | Para quem | O que o Claude Code entrega |
|---|---|---|
| `triagem-processos/` | Servidor de secretaria (JFCE) | Petições da caixa de tarefas classificadas por prioridade, com providência sugerida |
| `triagem-emails/` | Servidor que cuida da caixa da unidade | E-mails por prioridade, com prazo, responsável e rascunho de resposta |
| `advocacia-pasta-do-cliente/` | Advocacia | Linha do tempo, índice dos documentos e o que falta pedir ao cliente |
| `contabilidade-cruzamento/` | Contabilidade pública | Declarado × recolhido, com as divergências e a memória de cálculo |

Em cada pasta, comece pelo `COMECE-AQUI.md`.

## Antes de usar com material de verdade

- Material real só com autorização do seu órgão ou escritório e dentro das regras dele.
  **Processo sigiloso, ou de sigilo desconhecido, não entra.**
- Rodar o Claude Code no seu computador **não** mantém o conteúdo no computador: o texto
  vai para o serviço de IA. Use plano pago com o treinamento desligado.
- O Claude Code não entra no PJe, não abre sua caixa de e-mail e não envia nada: ele lê
  os arquivos que você colocar em `entrada/` e escreve em `saida/`.
