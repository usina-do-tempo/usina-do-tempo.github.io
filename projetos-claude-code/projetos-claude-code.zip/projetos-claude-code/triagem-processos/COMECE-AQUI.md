# Triagem de petições com o Claude Code

> **Material fictício.** Usar com dado real depende de autorização do seu órgão ou escritório;
> processo sigiloso ou de sigilo desconhecido não entra.

Você é servidor de uma vara federal. Todo dia chegam petições na caixa de tarefas do PJe. Aqui o Claude Code lê a lista
(exportada) e 16 petições de uma vez, classifica pela urgência e sugere a providência. **Ele não acessa o PJe**:
trabalha só nos arquivos desta pasta. Quem decide é você.

## Passo a passo

1. **Abra a pasta** `triagem-processos` no terminal (ou no app do Claude Code).
2. **Digite `claude`** e aperte Enter. Ele lê sozinho as regras do arquivo `CLAUDE.md`.
3. **Cole o pedido abaixo** e aperte Enter:

```
Faça a triagem da caixa de tarefas. Leia entrada/caixa-de-tarefas.csv e todas as petições em entrada/peticoes/.
Aplique regras/criterios.md e gere saida/triagem.csv e saida/triagem.md, como manda o CLAUDE.md.
Termine com o bloco CONFERÊNCIA.
```

4. **Abra a pasta `saida/`.** O `triagem.csv` abre no Excel; o `triagem.md` é o relatório para ler.
5. **Confira em 60 segundos:**
   - O CSV tem **16 linhas** (uma por linha da caixa) e as 8 colunas, na ordem certa?
   - Toda linha tem prioridade (URGENTE, ALTA, NORMAL ou BAIXA)?
   - Abra **duas petições** à sua escolha e compare com o `pedido_resumido`: o resumo diz o que a petição de fato pede?
   - Leia você mesmo as petições marcadas **BAIXA**: a pior falha é uma urgência classificada como rotina.
   - Os itens com alerta (`[VERIFICAR]`, `SUSPEITO`, `SIGILO`, `DUPLICADA`) fazem sentido? Procure o trecho citado na petição.
6. **Adapte ao seu trabalho:** edite `regras/criterios.md` (por exemplo, mude o que é URGENTE na sua vara) e troque os arquivos
   de `entrada/` pelo seu material, **desde que autorizado e não sigiloso**. Rode o mesmo pedido de novo.

## O que fica onde

- `entrada/` — a lista e as petições (fictícias). Não mexa durante a execução.
- `regras/criterios.md` — suas regras; pode editar.
- `saida/` — o resultado aparece aqui.
