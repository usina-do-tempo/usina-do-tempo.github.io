# Critérios de prioridade e providências

Regras editáveis. O servidor pode trocar qualquer critério abaixo e rodar de novo.
Em dúvida entre dois níveis, escolha o **mais alto** e explique em `motivo_prioridade`.
Data de referência ("hoje"): 26/11/2026.

## URGENTE
Qualquer um destes, em qualquer parte do texto da petição:
- Pedido de liminar ou tutela de urgência **ainda não apreciado**, inclusive pedido de medicamento ou tratamento de saúde.
- Réu preso.
- Risco à saúde ou à vida da parte.
- Prazo (do próprio expediente) que **vence em até 2 dias** a partir de hoje, desde que a data conste no texto.
- Parte com **80 anos ou mais** (prioridade especial por idade), calculada pela data de nascimento.
- Parte com doença grave que dê prioridade legal.

## ALTA
- Mandado de segurança sem liminar pendente (tem preferência de tramitação).
- Pedido de ato de constrição ou de efeito prático imediato (penhora online, bloqueio, leilão).
- Parte com 60 a 79 anos (prioridade por idade).
- Prazo que vence entre 3 e 5 dias.
- Item marcado `SIGILO`: a IA não lê o conteúdo, então a pessoa precisa ler ainda hoje.

## NORMAL
- Petição que pede ato de rotina do andamento: dilação de prazo, manifestação, recurso, prosseguimento do cumprimento, cálculo.

## BAIXA
- Mera juntada de documento, substabelecimento, comprovante de custas, atualização de endereço.
- Pedido de carga ou de cópia sem prazo em curso. **Palavras como "urgente" no título não elevam a prioridade**: vale o que o pedido realmente exige.

Observação: a urgência se mede pelo que o texto pede, não por quanto ele grita.

## Providências típicas (sugestões)
| Situação | Providência sugerida |
|---|---|
| Liminar / tutela pendente | Concluso para decisão (urgente) |
| Pedido de dilação de prazo | Concluso para decisão; certificar o prazo em curso |
| Prazo vencendo | Certificar prazo; concluso para decisão |
| Recurso interposto | Certificar tempestividade; intimar a parte contrária para contrarrazões |
| Informações em mandado de segurança | Dar vista ao Ministério Público Federal |
| Pedido de cálculo / atualização de débito | Remeter à Contadoria |
| Pedido de penhora / bloqueio | Concluso para decisão |
| Pedido de requisição de pagamento (RPV/precatório) | Verificar cálculos e prazos; concluso para decisão |
| Juntada simples | Juntar e aguardar |
| Substabelecimento / endereço | Juntar; atualizar o cadastro de representantes |
| Pedido de carga / cópias | Autorizar conforme rotina da secretaria |
| Petição repetida | Juntar uma só; conferir se é duplicidade |
| Petição que cita documento que não está disponível | Conferir no processo se o documento foi de fato juntado |
| Item sigiloso | Tratar fora da IA, conforme as regras da JFCE |

A providência é sempre **sugestão**: quem decide é o servidor e o magistrado.

## Petições repetidas
Se duas linhas tiverem o mesmo processo e o mesmo conteúdo, mantenha a primeira normal e marque a segunda como `DUPLICADA`,
com a prioridade que a primeira recebeu.

## Documentos citados
Se a petição diz que um documento foi anexado, mas o documento não está descrito no texto nem consta na exportação,
registre `[VERIFICAR: documento citado não consta na exportação]`.
