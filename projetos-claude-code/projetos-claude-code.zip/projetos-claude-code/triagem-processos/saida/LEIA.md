O resultado aparece aqui: `triagem.csv` e `triagem.md`.
