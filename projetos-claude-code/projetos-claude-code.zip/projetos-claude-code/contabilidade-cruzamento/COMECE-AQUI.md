# Conferência em lote: declarado x recolhido

> **Material fictício.** Usar com dado real depende de autorização do seu órgão ou escritório;
> processo sigiloso ou de sigilo desconhecido não entra.

Você vai pedir ao Claude Code que cruze o que 18 entidades fictícias **declararam** com o que o órgão
fictício **registrou como recolhido**, faça as contas **com um programa** (não de cabeça) e liste as
divergências. Quem analisa e decide é você.

## Passo a passo

1. Abra o terminal **dentro desta pasta** (`contabilidade-cruzamento`). No Windows: abra a pasta no
   Explorador, clique na barra de endereço, digite `cmd` e tecle Enter.
2. Digite `claude` e tecle Enter. (As contas saem de um pequeno programa que o próprio Claude escreve, em Python, Node.js ou PowerShell, conforme o que o computador tiver.)
3. Cole o pedido abaixo e tecle Enter. Se o Claude pedir permissão para rodar o script, aceite: ele só lê
   `entrada/` e escreve em `saida/`.
4. Abra a pasta `saida/`: `divergencias.csv` (abre no Excel), `relatorio.md` e `calcular.py` (as contas).
5. Faça a conferência de 60 segundos abaixo.
6. Para adaptar: troque os critérios em `regras/criterios.md` e o material em `entrada/`.

## O pedido para colar

```
Confira a competência 09/2026 desta pasta.
Cruze entrada/declaracoes.csv com entrada/recolhimentos.csv, leia as observações e siga regras/criterios.md.
Faça as contas com um script guardado em saida/ e gere saida/divergencias.csv e saida/relatorio.md.
Não lance nem conclua nada: só aponte as divergências para eu analisar.
```

## Conferência de 60 segundos

1. **Quantidade:** o número de linhas de `divergencias.csv` bate com o número de entidades de
   `declaracoes.csv` (mais algum recolhimento que não tenha declaração)?
2. **Uma conta na calculadora:** escolha uma divergência, refaça base × percentual e compare com
   `devido_recalculado` e `diferenca`.
3. **Soma das guias:** abra `recolhimentos.csv` e veja se alguma entidade pagou em mais de uma guia; confira
   se a soma foi usada.
4. **Nada de OK escondido:** nenhuma linha OK deve ter diferença fora de R$ 1,00 (para mais ou para menos).
5. **Dúvida declarada:** o que o Claude não soube resolver aparece como `[VERIFICAR]`, e o que parecia ordem
   dentro de uma observação aparece como `SUSPEITO`, sem mudar a situação.

Se algum item falhar, é aí que a sua análise é indispensável: o Claude Code acelera, a conferência continua humana.
