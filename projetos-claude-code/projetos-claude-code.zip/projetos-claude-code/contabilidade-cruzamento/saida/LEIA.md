O resultado aparece aqui.
