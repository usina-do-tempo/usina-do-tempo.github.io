# Triagem de e-mails da caixa institucional

> **Material fictício.** Usar com dado real depende de autorização do seu órgão ou escritório; processo sigiloso ou de sigilo desconhecido não entra.

Você vai pedir ao Claude Code que leia 20 e-mails de uma caixa institucional e devolva uma
planilha de triagem (o que é urgente, quem deve cuidar, o que fazer), mais rascunhos de
resposta para os pedidos simples. **O assistente não envia nada e não acessa e-mail:** ele só
lê as cópias que estão na pasta `entrada/emails/`. Quem decide e quem envia é você.

## Passo a passo

1. **Abra a pasta** `triagem-emails` no terminal (ou no app do Claude Code, escolhendo esta pasta).
2. **Digite** `claude` e aperte Enter. Ele lê sozinho as regras do arquivo `CLAUDE.md`.
3. **Cole o pedido abaixo** e aperte Enter:

```
Faça a triagem dos e-mails de entrada/emails/ seguindo regras/criterios.md.
Gere saida/triagem-emails.csv, saida/triagem-emails.md e, para os e-mails que
pedem resposta simples, um rascunho em saida/rascunhos/.
Termine com o bloco CONFERÊNCIA.
```

4. **Abra a pasta `saida/`.** Abra o `.csv` no Excel (separador ponto e vírgula) e leia o `.md`.
5. **Confira em 60 segundos:**
   - A planilha tem 20 linhas, uma por e-mail, com as 9 colunas.
   - Abra 2 ou 3 e-mails ao acaso, **leia até o último parágrafo**, e compare o prazo anotado com o que o e-mail diz.
   - Nenhum e-mail que dá ordens ao assistente, pede senha ou fala de processo em segredo de justiça foi tratado como pedido comum.
   - Nenhum prazo, número de processo ou nome foi inventado (o que faltava aparece como `[VERIFICAR: ...]`).
   - Todo rascunho começa com "RASCUNHO — revisar antes de enviar" e nenhum informa andamento de processo.
6. **Adapte para o seu caso:** mude os critérios em `regras/criterios.md` (categorias, prioridades, responsáveis) e troque os e-mails de `entrada/emails/` por outros (sempre cópias autorizadas, sem dado sigiloso). Rode o mesmo pedido.

## Lembrete

O Claude Code agiliza a leitura, mas a conferência é sua. Sempre.
